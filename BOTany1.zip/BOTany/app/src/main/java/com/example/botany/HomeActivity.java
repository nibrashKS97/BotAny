package com.example.botany;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.DateIntervalFormat;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeActivity extends AppCompatActivity {

    TextView weather_report,location_name;
    Button logout;
    TextView userNameTextView;
    CircleImageView profilePicture;
    FirebaseUser fUser;
    FirebaseAuth fAuth;
    DatabaseReference fRef;

    //weather api integration fetching country name from firebase database
    class Weather extends AsyncTask<String,Void,String> {

        @Override
        protected String doInBackground(String... address) {

            try {
                URL url = new URL(address[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                connection.connect();

                InputStream is = connection.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);

                int data = isr.read();
                String content = "";
                char ch;
                while (data != -1){
                    ch = (char) data;
                    content = content + ch;
                    data = isr.read();
                }
                return content;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        search();

        logout = (Button) findViewById(R.id.logout);
        userNameTextView = (TextView) findViewById(R.id.userNameTextView);
        profilePicture = (CircleImageView) findViewById(R.id.profilePicture);
        fAuth = FirebaseAuth.getInstance();
        fUser = fAuth.getCurrentUser();
        fRef = FirebaseDatabase.getInstance("https://botany-iub-default-rtdb.asia-southeast1.firebasedatabase.app").getReference("Users").child(fUser.getUid());
        fRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                UserHelperClass userData = snapshot.getValue(UserHelperClass.class);
                assert userData != null;
                userNameTextView.setText(userData.getName());
                if (userData.getImageURL().equals("default")){
                    profilePicture.setImageResource(R.drawable.profile_picture);
                }
                else {
                    Glide.with(getApplicationContext()).load(userData.getImageURL()).into(profilePicture);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(HomeActivity.this, "Database Error", Toast.LENGTH_SHORT).show();
            }
        });

        //for user to logout
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutAction();
            }
        });

    }

    public void search() {
        weather_report = (TextView) findViewById(R.id.weather_report);
        location_name = (TextView) findViewById(R.id.location_name);

        fAuth = FirebaseAuth.getInstance();
        fUser = fAuth.getCurrentUser();
        fRef = FirebaseDatabase.getInstance("https://botany-iub-default-rtdb.asia-southeast1.firebasedatabase.app").getReference("Users").child(fUser.getUid());
        fRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                UserHelperClass userData = snapshot.getValue(UserHelperClass.class);
                assert userData != null;
                location_name.setText(userData.getCountry());
                if (userData.getCountry().equals(null)){
                    location_name.setText("No Location");
                }
                else {

                    String cName = userData.getCountry();

                    String content;
                    Weather weather = new Weather();
                    try {
                        content = weather.execute("https://api.openweathermap.org/data/2.5/weather?q=" +
                                cName+"&units=metric&appid=1164903a1b37102502b2dd2e31b379b2").get();
                        Log.i("contentData",content);

                        JSONObject jsonObject = new JSONObject(content);
                        String weatherData = jsonObject.getString("weather");
                        String mainTemperature = jsonObject.getString("main");
                        JSONArray array = new JSONArray(weatherData);

                        String main = "";
                        String description = "";
                        String temperature = "";

                        for(int i=0; i<array.length(); i++){
                            JSONObject weatherPart = array.getJSONObject(i);
                            main = weatherPart.getString("main");
                            description = weatherPart.getString("description");
                        }

                        JSONObject mainPart = new JSONObject(mainTemperature);
                        temperature = mainPart.getString("temp");

                        Log.i("Temperature",temperature);

                        String resultText = "Main: "+main+", Description: "+description+"\nTemperature: "+temperature +"°C";
                        weather_report.setText(resultText);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(HomeActivity.this, "Weather Database Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void logoutAction() {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }

}